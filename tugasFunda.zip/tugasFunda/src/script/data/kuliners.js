const kuliners = [{
        name: "Karedok",
        provinsi: "jawa Barat",
        fanArt: "https://images.app.goo.gl/32EpHRCv8tFAeNZW9",
        description: "Karedok dibuat dengan bahan-bahan sayuran mentah antara lain; mentimun, taoge, kol, kacang panjang, ubi, daun kemangi, dan terong atau leunca. Sedangkan sausnya adalah bumbu kacang yang dibuat dari cabai merah, bawang putih, kencur, kacang tanah, air asam, gula jawa, garam, dan terasi. Salah satu ciri dari karedok adalah menggunakan oncom bakar. Bila tidak menggunakan oncom bakar disebutnya lotek mentah (atah)."
    },
    {
        name: "kerak telor",
        provinsi: "DKI Jakart",
        fanArt: "https://images.app.goo.gl/eeZ2BZCc84ApvAW19",
        description: "Kerak telor jadi salah satu makanan yang tak bisa dipisahkan dari Kota Jakarta, apalagi saat momen Ulang Tahun Jakarta. Kudapan gurih ini kabarnya sudah disajikan sejak zaman penjajahan Belanda,Kerak telor bukanlah makanan kekinian, keberadaan kerak telor bahkan sudah ada sejak tahun 1970-an. Tapi hingga kini, kerak telor masih jadi ikon kuliner khas Betawi yang tak tergerus zaman. Dilansir dari berbagai sumber, kerak telor tercipta secara tak sengaja. Berawal dari banyaknya pohon kelapa di Jakarta, saat itu masih Batavia, sekelompok warga Betawi mencoba memanfaatkan buah kelapa untuk diolah jadi makanan. sumber detik.com"
    },
];
export default kuliners;
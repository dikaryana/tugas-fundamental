import "regenerator-runtime";
import "./styles/style.css";
import "./script/component/app-bar.js";
import '../component/search-bar.js';
import "./src/script/component/app-bar.js";
import '../component/kuliner-list.js';
import main from "./src/script/view/main.js";
document.addEventListener("DOMContentLoaded", main);